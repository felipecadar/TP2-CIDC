Please find the following files:

For a full view of the project, please refer to the github repository at [https://github.com/felipecadar/TP2-CIDC](https://github.com/felipecadar/TP2-CIDC)

```
.
├── k8s/
│   ├── deployment.yaml
│   ├── pvc.yaml
│   ├── service.yaml
├── playlist-recommendation-system/
│   ├── backend/
│   │   ├── app.py
│   │   ├── Dockerfile
│   │   ├── requirements.txt
│   ├── frontend/
│   │   ├── Dockerfile
│   │   ├── index.html
│   │   ├── script.js
│   │   ├── styles.css
│   ├── ml-training/
│   │   ├── app.py
│   │   ├── Dockerfile
│   │   ├── requirements.txt
│   │   ├── templates/
│   │   │   ├── index.html
├── Documentation.pdf
├── Manifest.yaml
```
